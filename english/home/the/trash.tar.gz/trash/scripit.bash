
N=$(( $RANDOM % 50 + 100 ))
ALPHABET=( {a..z} )


while (( N >= 1 ))
do
	M=$(( 200 - 13 ))
	RESULT="key_fragment_"
	while (( M >= 1 ))
	do
		I=$(( RANDOM % 26 ))
		RESULT="${RESULT}${ALPHABET[I]}"
		(( M-- ))
	done

	touch $RESULT
	(( N-- )) 
done



