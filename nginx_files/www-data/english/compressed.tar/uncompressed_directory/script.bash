#!/bin/bash

# Number of files to generate
num_files=2064

generate_random_filename() {
	echo $((RANDOM * RANDOM * RANDOM * RANDOM % 100000000))
}

generate_random_content() {
	# Generate random ASCII content of a random length between 10 and 100
	length=$((10 + RANDOM % 91))
	tr -dc 'a-zA-Z0-9' < /dev/urandom | head -c "$length"
}

for ((i=1; i<=num_files; i++)); do
	filename=$(generate_random_filename)
	
	# Randomly decide if the file should be empty or contain content
	if (( RANDOM % 2 == 0 )); then
		touch "$filename"  # Create an empty file
	else
		generate_random_content > "$filename"  # Write random content
	fi
done

